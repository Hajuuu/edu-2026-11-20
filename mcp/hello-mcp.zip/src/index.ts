#!/usr/bin/env node
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

// 1) 서버 생성: 초기화 응답의 serverInfo로 전달됩니다.
const server = new McpServer({ name: "hello-mcp", version: "1.0.0" });

// 2) 도구 등록 = server.registerTool(name, config, handler);
server.registerTool(
  // name
  "add",
  // config
  {
    title: "두 수 더하기",
    description: "두 정수를 더한 결과를 반환합니다.",
    inputSchema: {
      a: z
        .number()
        .describe("첫 번째 수"),
      b: z
        .number()
        .describe("두 번째 수"),
    },
  },
  // handler
  async ({ a, b }) => {
    // 도구 실행 오류: 예외를 던지지 않고 isError 결과로 반환하면 LLM이 메시지를 읽고 대응합니다.
    if (!Number.isInteger(a) || !Number.isInteger(b)) {
      return {
        content: [{ type: "text", text: "a와 b는 정수여야 합니다." }],
        isError: true,
      };
    }

    // 정상 결과
    return { content: [{ type: "text", text: String(a + b) }] };
  },
);

// 3) 전송 계층 연결: 이 시점부터 표준 입력으로 들어오는 요청을 처리합니다.
await server.connect(new StdioServerTransport());
console.error("[hello-mcp] started"); // 로그는 stderr로 출력합니다.
